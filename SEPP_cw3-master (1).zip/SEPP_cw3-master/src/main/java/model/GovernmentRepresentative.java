package model;

public class GovernmentRepresentative extends User {
    public GovernmentRepresentative(String email, String password, String paymentAccountEmail) {
        super(email, password, paymentAccountEmail);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
