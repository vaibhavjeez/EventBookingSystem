package model;

public enum BookingStatus {
    ACTIVE,
    CANCELLED_BY_CONSUMER,
    CANCELLED_BY_PROVIDER,
    PAYMENT_FAILED
}
