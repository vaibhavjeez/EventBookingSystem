package model;

public enum EventType {
    Dance,
    Movie,
    Music,
    Sports,
    Theatre
}
