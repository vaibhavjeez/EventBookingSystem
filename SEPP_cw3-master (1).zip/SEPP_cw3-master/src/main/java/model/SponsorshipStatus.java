package model;

public enum SponsorshipStatus {
    ACCEPTED,
    PENDING,
    REJECTED
}
